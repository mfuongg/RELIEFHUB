import { useState } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';
import PageTransition from '../../components/PageTransition';
import { Send } from 'lucide-react';

const ITEMS_LIST = ['Gạo', 'Mì gói', 'Nước uống', 'Áo phao', 'Thuốc men', 'Chăn màn', 'Quần áo', 'Nến', 'Pin'];

export default function CitizenRequest() {
  const { addNeed, user, disasters } = useApp();
  const [form, setForm] = useState({ citizen: user?.name || '', area: '', items: '', quantity: '', urgency: 'medium', households: 1, notes: '' });
  const [sent, setSent] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);

  const toggleItem = (item) => {
    setSelectedItems(prev => prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const itemsStr = selectedItems.length > 0 ? selectedItems.join(', ') + (form.items ? ', ' + form.items : '') : form.items;
    addNeed({ ...form, citizen: user?.name, items: itemsStr });
    setSent(true);
  };

  if (sent) return (
    <PageTransition>
      <div className="page-container">
        <div className="max-w-md mx-auto text-center py-16">
          <motion.div animate={{ y: [0, -10, 0] }} transition={{ repeat: 2, duration: 0.5 }} className="text-6xl mb-4">📬</motion.div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Yêu cầu đã gửi!</h2>
          <p className="text-gray-500 mb-6">Cán bộ địa phương sẽ xác minh và phản hồi sớm nhất có thể.</p>
          <button onClick={() => { setSent(false); setSelectedItems([]); }} className="btn-primary">Gửi yêu cầu khác</button>
        </div>
      </div>
    </PageTransition>
  );

  return (
    <PageTransition>
      <div className="page-container">
        <div className="mb-6">
          <h1 className="section-title">Gửi yêu cầu hỗ trợ</h1>
          <p className="section-subtitle">Điền thông tin để được hỗ trợ sớm nhất</p>
        </div>
        <div className="max-w-2xl">
          <div className="card">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><label className="label">Họ tên</label>
                  <input value={form.citizen} onChange={e => setForm({ ...form, citizen: e.target.value })} className="input-field" required />
                </div>
                <div><label className="label">Khu vực</label>
                  <select value={form.area} onChange={e => setForm({ ...form, area: e.target.value })} className="input-field" required>
                    <option value="">-- Chọn khu vực --</option>
                    {disasters.map(d => <option key={d.id} value={d.area}>{d.area}</option>)}
                    <option value="Khác">Khác</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="label">Hàng hóa cần hỗ trợ (chọn nhanh)</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {ITEMS_LIST.map(item => (
                    <button key={item} type="button" onClick={() => toggleItem(item)}
                      className={`px-3 py-1.5 rounded-xl text-sm border-2 transition-all ${selectedItems.includes(item) ? 'border-purple-500 bg-purple-50 text-purple-700' : 'border-gray-200 text-gray-600 hover:border-gray-300'}`}>
                      {item}
                    </button>
                  ))}
                </div>
                <input value={form.items} onChange={e => setForm({ ...form, items: e.target.value })} className="input-field" placeholder="Hoặc nhập thêm mặt hàng khác..." />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div><label className="label">Số lượng hộ gia đình</label>
                  <input type="number" value={form.households} onChange={e => setForm({ ...form, households: e.target.value })} className="input-field" min={1} />
                </div>
                <div><label className="label">Mức độ khẩn cấp</label>
                  <select value={form.urgency} onChange={e => setForm({ ...form, urgency: e.target.value })} className="input-field">
                    <option value="low">🟢 Thấp</option>
                    <option value="medium">🟡 Trung bình</option>
                    <option value="high">🟠 Cao</option>
                    <option value="critical">🔴 Khẩn cấp</option>
                  </select>
                </div>
              </div>

              <div><label className="label">Ghi chú thêm</label>
                <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="input-field" rows={3} placeholder="Thông tin bổ sung về hoàn cảnh, địa chỉ cụ thể..." />
              </div>

              <button type="submit" className="w-full btn-primary flex items-center justify-center gap-2">
                <Send className="w-4 h-4" /> Gửi yêu cầu hỗ trợ
              </button>
            </form>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}

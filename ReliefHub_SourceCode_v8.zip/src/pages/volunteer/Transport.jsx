import { useState } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';
import PageTransition from '../../components/PageTransition';
import { MapPin, Truck, Package, Clock } from 'lucide-react';

const TRANSPORTS = [
  { id: 1, code: 'VT-001', from: 'Kho Đà Nẵng', to: 'Quảng Bình', items: 'Gạo 500kg, Mì gói 50 thùng', driver: 'Đỗ Quang Huy', vehicle: 'Xe tải 5T - 43A-12345', status: 'in-transit', departDate: '2024-10-08 07:00', etaDate: '2024-10-10 12:00', lat: 16.8, lng: 107.1 },
  { id: 2, code: 'VT-002', from: 'Kho Hà Nội', to: 'Thanh Hóa', items: 'Chăn màn 200 cái', driver: 'Nguyễn Văn B', vehicle: 'Xe tải 3T - 30A-67890', status: 'delivered', departDate: '2024-10-05 06:00', etaDate: '2024-10-07 10:00', lat: 20.1, lng: 105.8 },
  { id: 3, code: 'VT-003', from: 'Kho TP.HCM', to: 'Đắk Lắk', items: 'Nước uống 100 thùng', driver: 'Trần Văn C', vehicle: 'Xe tải 2T - 51A-11111', status: 'pending', departDate: '2024-10-09 08:00', etaDate: '2024-10-12 14:00', lat: 12.7, lng: 108.0 },
];

export default function VolunteerTransport() {
  const [selected, setSelected] = useState(null);

  const statusColor = { 'in-transit': 'badge-info', 'delivered': 'badge-verified', 'pending': 'badge-pending' };
  const statusLabel = { 'in-transit': '🚚 Đang vận chuyển', 'delivered': '✓ Đã giao', 'pending': '⏳ Chờ xuất kho' };

  return (
    <PageTransition>
      <div className="page-container">
        <div className="mb-6">
          <h1 className="section-title">Lịch vận chuyển</h1>
          <p className="section-subtitle">Theo dõi và quản lý các chuyến vận chuyển hàng cứu trợ</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Transport list */}
          <div className="space-y-4">
            {TRANSPORTS.map((t, i) => (
              <motion.div key={t.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                onClick={() => setSelected(t)}
                className={`card cursor-pointer transition-all ${selected?.id === t.id ? 'ring-2 ring-sky-500' : 'hover:shadow-card-hover'}`}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sky-600 text-sm">{t.code}</span>
                      <span className={statusColor[t.status]}>{statusLabel[t.status]}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-700 mt-1.5">
                      <MapPin className="w-3.5 h-3.5 text-gray-400" />
                      <span className="font-medium">{t.from}</span>
                      <span className="text-gray-400">→</span>
                      <span className="font-medium">{t.to}</span>
                    </div>
                  </div>
                </div>
                <div className="text-xs text-gray-500 space-y-1">
                  <div className="flex items-center gap-1"><Package className="w-3 h-3" /> {t.items}</div>
                  <div className="flex items-center gap-1"><Truck className="w-3 h-3" /> {t.vehicle}</div>
                  <div className="flex items-center gap-1"><Clock className="w-3 h-3" /> Khởi hành: {t.departDate} | ETA: {t.etaDate}</div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Map placeholder */}
          <div className="card">
            <h3 className="font-bold text-gray-900 mb-3">Bản đồ theo dõi GPS</h3>
            {selected ? (
              <div className="space-y-4">
                <div className="bg-gradient-to-br from-sky-100 to-blue-200 rounded-xl h-48 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-4xl mb-2">🗺️</div>
                      <div className="text-sm font-medium text-sky-700">{selected.from} → {selected.to}</div>
                      <div className="text-xs text-sky-600 mt-1">Tọa độ: {selected.lat}°N, {selected.lng}°E</div>
                    </div>
                  </div>
                  {/* Animated vehicle icon */}
                  <motion.div
                    animate={{ x: [-20, 20, -20] }}
                    transition={{ repeat: Infinity, duration: 3 }}
                    className="absolute text-3xl"
                  >🚚</motion.div>
                </div>
                <div className="space-y-2 text-sm">
                  {[['Mã chuyến', selected.code], ['Lái xe', selected.driver], ['Phương tiện', selected.vehicle], ['Hàng hóa', selected.items]].map(([k, v]) => (
                    <div key={k} className="flex justify-between py-1.5 border-b border-gray-50">
                      <span className="text-gray-500">{k}:</span>
                      <span className="font-medium text-gray-900">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-gray-400">
                <div className="text-center">
                  <div className="text-4xl mb-3">👆</div>
                  <p className="text-sm">Chọn một chuyến để xem bản đồ</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
